<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use App\Models\Especie;


class EspecieSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        Especie::create(['nomcientifico'=>'Ave']);
        Especie::create(['nomcientifico'=>'Reptiles']);
        Especie::create(['nomcientifico'=>'Mamiferos']);
        
    }
}
