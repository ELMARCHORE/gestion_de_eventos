# Sistema de eventos

# Gestión de Eventos

Este proyecto es una aplicación para gestionar eventos desarrollada en Laravel.

## Descarga del Proyecto

Para descargar el proyecto desde el repositorio de GitLab, sigue estos pasos:

1. Abre tu navegador web y ve a la página del repositorio en GitLab: [https://gitlab.com/tecnoprofe/gestion-de-eventos/](https://gitlab.com/tecnoprofe/gestion-de-eventos/)
2. Haz clic en el botón "Download ZIP" para descargar el proyecto como un archivo ZIP.

## Instalación del Proyecto

Una vez que hayas descargado el proyecto, sigue estos pasos para instalarlo:

1. Mueve la carpeta del proyecto descomprimido a la carpeta de proyectos de tu servidor local. Por ejemplo, si estás utilizando Laragon, puedes mover la carpeta a `C:/laragon/www`.
2. Abre tu terminal o línea de comandos y navega hasta la carpeta del proyecto.
3. Ejecuta `composer install` para instalar las dependencias del proyecto.
4. Copia el archivo `.env.example` y pégalo como `.env`.
5. Genera una nueva clave de aplicación con `php artisan key:generate`.
6. Configura la conexión a la base de datos en el archivo `.env`.
7. Ejecuta las migraciones de la base de datos con `php artisan migrate`.
8. Inicia el servidor local con `php artisan serve`.
9. Abre tu navegador web y navega a la URL proporcionada por el servidor local para acceder a la aplicación.

<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400"></a></p>


## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
