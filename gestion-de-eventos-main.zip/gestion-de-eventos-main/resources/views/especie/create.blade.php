<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h2>crear un nueva especie</h2>
<form method="POST" action="{{ route('especie.store') }}">
    @csrf
    <!-- Campos del formulario para crear -->
    <label for="">Nombre Cientifico</label>
    <input type="text" name="nomcientifico">
    <br>
    <label for="">nomvulgar </label>
    <input type="text" name="nomvulgar">
    <br>
    <button type="submit">Guardar</button>
</form>

</body>
</html>